# generic-syntax
A self-contained repository for the paper [A Scope-and-Type Safe Universe of Syntaxes with Binding, Their Semantics and Proofs](https://gallais.github.io/pdf/icfp18.pdf)

# Typechecking

[![Travis Status](https://api.travis-ci.org/gallais/generic-syntax.svg?branch=master)](https://travis-ci.org/gallais/generic-syntax)

To check this development, you'll need:
* Agda 2.5.4.2
* Agda's Standard Library 0.17
