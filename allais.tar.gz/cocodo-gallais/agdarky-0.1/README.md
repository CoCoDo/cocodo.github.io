# agdarky
Agda suffices: software written from A to Z in Agda
